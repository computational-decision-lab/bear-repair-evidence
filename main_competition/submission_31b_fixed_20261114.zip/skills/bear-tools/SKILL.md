---
name: bear-tools
description: Deterministic Python symbol retrieval and a task-budget adviser for repository repair. Use retrieval for locating code; use decide only when the system requests adaptive control.
---

Run `scripts/bear.py` with `run_skill_script`. Pass `args` as a list of strings.

Retrieve relevant Python definitions:

`["--mode", "retrieve", "--query", "the exception or symbol from the issue", "--k", "8"]`

The retriever uses only files in the current workspace, never reference patches, external tests, or internet resources. Returned line ranges are locations to inspect, not instructions to change code. It includes async definitions and tolerates syntax failures.

When the system asks for adaptive control, request advice:

`["--mode", "decide", "--remaining", "160", "--phase", "repair", "--last-action", "read", "--last-key", "package.module.function", "--last-outcome", "new"]`

Use the latest observed `get_status.time_seconds_remaining`. `phase` and the previous-operation summary are agent reports. The script independently hashes the workspace diff to distinguish a legitimate recheck after editing from an unchanged repeated operation. The ledger is stored under `/tmp`, outside the submitted patch. It reports uncalibrated gain priorities and prior action costs; it does not estimate a measured probability of passing hidden tests. If advice fails, continue the repair using native tools.

Do not invoke the adviser if the system specifies the fixed-workflow control condition. Both experimental conditions can use the same retriever and tools.
