#!/usr/bin/env python3
"""BEAR v0: auditable heuristic budget advice and source-only AST retrieval.

No trained repairability estimator is supplied. Numeric gains are declared
priorities, not calibrated success probabilities. Advice does not execute edits.
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter
from dataclasses import dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import time


@dataclass(frozen=True)
class Action:
    name: str
    gain: float
    seconds: float
    exploratory: bool = False


COST_PRIORS = {"lexical": 8., "ast": 8., "graph": 10., "semantic": 12.,
               "read": 15., "edit": 45., "test": 30., "verify": 30.}
PRIORITIES = {
    "locate": {"lexical": .18, "ast": .14, "graph": .08, "semantic": .07, "read": .10, "edit": .02},
    "repair": {"lexical": .01, "ast": .01, "graph": .01, "read": .06, "edit": .35},
    "test": {"read": .02, "edit": .01, "test": .35, "verify": .28},
    "recover": {"lexical": .13, "ast": .13, "graph": .18, "semantic": .04, "read": .22, "edit": .09},
}
EXPLORATORY = {"lexical", "ast", "graph", "semantic", "read"}


def workspace_root():
    """ADK materializes skills in a temporary cwd; PWD retains the sandbox cwd."""
    cwd = Path.cwd().resolve()
    materialized_root = Path(__file__).resolve().parents[1]
    if cwd != materialized_root:
        return cwd
    for candidate in [Path('/workspace'), Path(os.environ.get('PWD', '/nonexistent'))]:
        if candidate.is_dir() and candidate.resolve() != materialized_root:
            probe = subprocess.run(['git', '-C', str(candidate), 'rev-parse', '--show-toplevel'],
                                   capture_output=True, text=True, timeout=5)
            if probe.returncode == 0:
                return Path(probe.stdout.strip()).resolve()
    raise RuntimeError('Cannot locate the repository from the ADK skill working directory')


def rank_actions(actions, remaining, reserve=0., blocked=(), minimum_rate=0.):
    """Myopic gain/cost heuristic with an explicit feasibility reserve.

    This is not an optimal policy for complementary evidence or uncertain costs.
    """
    if not math.isfinite(remaining) or remaining < 0:
        raise ValueError("remaining must be finite and nonnegative")
    if not math.isfinite(reserve) or reserve < 0:
        raise ValueError("reserve must be finite and nonnegative")
    ranked = []
    for action in actions:
        if not math.isfinite(action.gain) or not math.isfinite(action.seconds) or action.seconds <= 0:
            raise ValueError("action gain must be finite and cost finite and positive")
        if action.name in blocked or action.gain <= 0:
            continue
        if action.seconds + (reserve if action.exploratory else 5.) > remaining:
            continue
        rate = action.gain / action.seconds
        if rate <= minimum_rate:
            continue
        ranked.append({"action": action.name, "priority": action.gain,
                       "cost_prior_seconds": action.seconds, "priority_per_second": rate})
    return sorted(ranked, key=lambda x: (-x["priority_per_second"], x["action"]))


def patch_fingerprint(root):
    result = subprocess.run(["git", "diff", "HEAD", "--", "."], cwd=root,
                            capture_output=True, timeout=5)
    if result.returncode:
        raise RuntimeError("Cannot fingerprint source changes: git diff failed")
    # Include untracked source content: git diff alone excludes new repair files.
    extra = subprocess.run(["git", "ls-files", "--others", "--exclude-standard"],
                           cwd=root, capture_output=True, text=True, timeout=5)
    if extra.returncode:
        raise RuntimeError("Cannot enumerate untracked source files")
    digest = hashlib.sha256(result.stdout)
    for name in sorted(extra.stdout.splitlines()):
        if Path(name).name.startswith('.adk_exec_') or '__pycache__' in Path(name).parts:
            continue
        path = (root / name).resolve()
        if root not in path.parents or not path.is_file() or path.is_symlink():
            continue
        if path.stat().st_size <= 1024 * 1024:
            digest.update(name.encode()); digest.update(path.read_bytes())
    return digest.hexdigest()


def decide(args):
    root = workspace_root()
    task_key = hashlib.sha256(str(root).encode()).hexdigest()[:20]
    state_path = Path(args.ledger) if args.ledger else Path('/tmp') / ('bear_' + task_key + '.json')
    if root == state_path.resolve() or root in state_path.resolve().parents:
        raise ValueError("The ledger must be outside the workspace")
    ledger = json.loads(state_path.read_text()) if state_path.exists() else {"schema_version": 1, "events": []}
    fingerprint = patch_fingerprint(root)
    event = {"timestamp_monotonic": time.monotonic(), "source_hash": fingerprint,
             "action": args.last_action, "key": args.last_key,
             "outcome": args.last_outcome, "phase": args.phase,
             "remaining_seconds_reported": args.remaining, "report_source": "agent_report"}
    if args.last_action != "none":
        ledger["events"].append(event)
    repeats = Counter((e["action"], e["key"], e["source_hash"])
                      for e in ledger["events"] if e["outcome"] in {"empty", "same", "error"})
    blocked = sorted({action for (action, _, source), count in repeats.items()
                      if source == fingerprint and count >= 2 and action in EXPLORATORY})
    reserve = 80. if args.phase in {"locate", "repair", "recover"} else 35.
    actions = [Action(name, gain, COST_PRIORS[name], name in EXPLORATORY)
               for name, gain in PRIORITIES[args.phase].items()]
    ranked = rank_actions(actions, args.remaining, reserve, blocked)
    chosen = ranked[0]["action"] if ranked else "stop"
    # A reported pass only ends a test phase; edits after that pass invalidate it.
    if args.phase == "test" and args.last_outcome == "pass" and args.last_action in {"test", "verify"}:
        chosen = "stop"
    result = {"action": chosen, "estimator": "uncalibrated_priority_v0",
              "scope": "per_task_advice", "reserve_seconds": reserve,
              "blocked_action_families": blocked, "ranked_actions": ranked,
              "source_hash": fingerprint,
              "stop_instruction": "Inspect diff and submit the best available patch; do not claim unseen tests passed."}
    ledger["decisions"] = ledger.get("decisions", []) + [{**event, **result}]
    state_path.parent.mkdir(parents=True, exist_ok=True)
    temp = state_path.with_suffix(state_path.suffix + ".tmp")
    temp.write_text(json.dumps(ledger, indent=2) + "\n"); temp.replace(state_path)
    return result


def terms(text):
    words = re.findall(r"[A-Za-z_][A-Za-z_0-9]*", text)
    return {piece.lower() for word in words for piece in [word, *re.findall(r"[A-Z]?[a-z]+|[A-Z]+(?=[A-Z]|$)", word)] if len(piece) > 2}


def python_files(root, skipped):
    for directory, subdirs, files in os.walk(root):
        subdirs[:] = sorted(d for d in subdirs if d not in skipped and not (Path(directory) / d).is_symlink())
        for name in sorted(files):
            if name.endswith('.py') and not name.startswith('.adk_exec_'):
                yield Path(directory) / name


def retrieve(args):
    root = workspace_root()
    query = terms(args.query)
    results = []
    skipped = {".git", ".venv", "venv", "node_modules", "__pycache__", ".tox"}
    start = time.monotonic()
    files_scanned = parse_errors = 0
    for path in python_files(root, skipped):
        rel = path.relative_to(root)
        if any(part in skipped for part in rel.parts) or path.is_symlink():
            continue
        if root not in path.resolve().parents or path.stat().st_size > 512000:
            continue
        if time.monotonic() - start > 10:
            break
        files_scanned += 1
        try:
            source = path.read_text(errors="replace")
            tree = ast.parse(source)
        except (SyntaxError, ValueError, OSError):
            parse_errors += 1
            continue
        lines = source.splitlines()
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                continue
            end = getattr(node, "end_lineno", node.lineno)
            snippet = "\n".join(lines[node.lineno - 1:min(end, node.lineno + 30)])
            score = 3 * len(query & terms(node.name)) + len(query & terms(str(rel))) + len(query & terms(snippet))
            if score:
                results.append({"file": str(rel), "symbol": node.name, "start_line": node.lineno,
                                "end_line": end, "score": score, "async": isinstance(node, ast.AsyncFunctionDef)})
    results.sort(key=lambda r: (-r["score"], r["file"], r["start_line"]))
    return {"results": results[:args.k], "files_scanned": files_scanned,
            "parse_errors": parse_errors, "elapsed_seconds": time.monotonic() - start,
            "truncated_scan": time.monotonic() - start > 10}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=["decide", "retrieve"], default="decide")
    parser.add_argument("--remaining", type=float, default=0.)
    parser.add_argument("--phase", choices=list(PRIORITIES), default="locate")
    parser.add_argument("--last-action", choices=["none", *COST_PRIORS], default="none")
    parser.add_argument("--last-key", default="")
    parser.add_argument("--last-outcome", choices=["none", "new", "empty", "same", "error", "pass", "fail"], default="none")
    parser.add_argument("--ledger")
    parser.add_argument("--query", default="")
    parser.add_argument("--k", type=int, default=8)
    args = parser.parse_args()
    if not 1 <= args.k <= 50:
        parser.error("k must be between 1 and 50")
    print(json.dumps(retrieve(args) if args.mode == "retrieve" else decide(args)))


if __name__ == "__main__":
    main()
