# BEAR paper review snapshot v6

Private, versioned review materials; not a public release or a submitted Writeup.

Run with Python 3.10 or newer, without external dependencies:

    python reproduce.py

This checks every allowlisted payload hash, recomputes all 9 architecture
rounds' counts/reported costs/paired statistics, and checks the 129-task representation
and evaluation-qualification arithmetic against canonical derived results.
The bundled rounds contain 162 assignments.
The original nine development rounds reuse six issues; prospective cohorts, when
included, are separate rounds with their full registered denominators. Repeated
assignments are not independent tasks. Positive development differences do not
establish general superiority.

The inputs are content-limited derived measurements. No problem statements,
reference patches, external tests, model weights, raw agent traces, official
source repositories, credentials, or cached packages are included. Reproducing
arithmetic does not independently verify the source observations or rerun the
models. Source record hashes permit linking an authorized private audit to
this snapshot; hashes alone are not open-data access.

For a data-free executable example, extract witness_diagnostics_v2.zip and
follow its README. Its eleven subprocess fixtures exercise mechanical source
provenance and freshness, not repair performance or semantic relevance.
audit_tools contains two standalone JSON/ATIF audit utilities. Run --help;
they require your own run_manifest/request logs or traces in the documented
layout, and contain no private traces. Reported phase activation and valid
tool delivery are not proof of useful verification.

When present, bearcheck_0_3_3.zip adds an installable API/CLI, versioned schema,
and a one-command offline rerun (`python reproduce.py`) of all 64 designed
diagnostic cases, seven subprocess checks, demo and packaged-CLI integration.
All known semantic counterexamples and unsupported valid checks remain visible.
This independently executable resource does not establish general diagnostic
accuracy, repair gains, outside adoption or a public release. Phase-budget
aggregates, when included, reproduce observed event timing and token arithmetic;
the first recorded verifier event is not its exact start time.

When real_check_replay_summary.json is present, the arithmetic rerun includes
every registered retrospective check invocation and its unsupported shapes,
judgments and measured costs. It does not rerun the private checks or distribute
their bodies. All ten invocations are exposed development data: four reused
issues and eight unique scripts, with zero supported shapes and no improved
outer judgment. Synthetic conformance must not conceal this coverage failure.

The paper's original sources are cited in its References. Diagnostic code is
Apache-2.0-licensed; competition data and third-party models are not redistributed.
Do not attach private experimental kernels as public Writeup resources.
