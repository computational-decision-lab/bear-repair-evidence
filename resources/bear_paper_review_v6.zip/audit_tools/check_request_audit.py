#!/usr/bin/env python3
"""Compare observed model-request declarations with compiled agent tool names."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory',type=Path)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    manifest=json.loads((args.directory/'run_manifest.json').read_text())
    path=args.directory/'model_request_audit.jsonl'
    if not path.is_file():
        raise ValueError('Actual model request audit is missing; compilation alone is not delivery evidence')
    rows=[json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    if not rows:
        raise ValueError('No observed requests')
    policies={}
    for policy in manifest['plan']['policies']:
        selected=[r for r in rows if r.get('policy')==policy]
        with_tools=[r for r in selected if r.get('tool_names')]
        expected=set(manifest['compilation'][policy]['tool_names'])
        phase_names=manifest['compilation'][policy].get('agent_tool_names')
        expected_sets=[set(names) for names in phase_names.values()] if phase_names else [expected]
        mismatches=[{'index':r['index'],'missing':sorted(expected-set(r['tool_names'])),
                     'additional':sorted(set(r['tool_names'])-expected)} for r in with_tools
                    if not any(set(r['tool_names'])==names for names in expected_sets)]
        policies[policy]={'requests':len(selected),'requests_with_tools':len(with_tools),
                          'requests_without_tools':len(selected)-len(with_tools),
                          'tool_names_match_compilation_for_all_nonempty_requests':bool(with_tools) and not mismatches,
                          'mismatches':mismatches,'expected_tool_names':sorted(expected),
                          'seeds_with_tools':dict(Counter(str(r.get('seed')) for r in with_tools)),
                          'temperatures_with_tools':dict(Counter(str(r.get('temperature')) for r in with_tools)),
                          'schema_hashes':sorted({r['tool_schema_sha256'] for r in with_tools})}
        if phase_names:
            policies[policy]['expected_tool_names_by_agent']=phase_names
    schemas={}
    for path in sorted((args.directory/'model_request_schemas').glob('*.json')):
        tools=json.loads(path.read_text())
        actual=hashlib.sha256(json.dumps(tools,sort_keys=True,default=str).encode()).hexdigest()
        if actual!=path.stem:
            raise ValueError('Observed schema hash mismatch')
        schema={}
        for tool in tools:
            function=tool.get('function',{})
            parameters=function.get('parameters',{})
            schema[function.get('name')]={'required':parameters.get('required',[]),'properties':sorted(parameters.get('properties',{}))}
        schemas[path.stem]=schema
    result={'policies':policies,'observed_schema_summaries':schemas,'audit_requests':len(rows),
            'interpretation':'Observed client arguments establish the recorded delivery, not model comprehension or successful execution. Requests without tools may include context compaction; retain them separately.'}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(policies,indent=2))


if __name__=='__main__':
    main()
