#!/usr/bin/env python3
"""Audit delivered workflow phases and candidate checks, never infer correctness.

Counts include every assignment in the frozen manifest. A command mentioning
pytest/assert is only a candidate for review: exit zero alone is not evidence
that the original issue was tested. Raw traces remain private.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re


def decoded(value):
    if isinstance(value, str):
        try:
            return json.loads(value)
        except (ValueError, TypeError):
            return None
    return value


def joined_calls(trace):
    """Join only identified or unambiguous observations; preserve uncertainty."""
    calls = []
    ids = {}
    unmatched_observations = 0
    for step in trace['steps']:
        author = (step.get('extra') or {}).get('author')
        for index, call in enumerate(step.get('tool_calls', [])):
            entry = {**call, 'step_id': step['step_id'], 'call_index': index,
                     'author': (call.get('extra') or {}).get('author') or author,
                     'observation': None, 'observation_step_id': None}
            identifier = call.get('tool_call_id')
            if identifier:
                if identifier in ids:
                    raise ValueError('Duplicate tool-call identifier')
                ids[identifier] = entry
            calls.append(entry)
        observation = step.get('observation')
        if not observation:
            continue
        identifier = observation.get('tool_call_id')
        if identifier:
            match = ids.get(identifier)
        else:
            extra = observation.get('extra') or {}
            candidates = [c for c in calls if c['observation_step_id'] is None
                          and (not extra.get('tool_name') or c['function_name'] == extra['tool_name'])
                          and (not extra.get('author') or c['author'] == extra['author'])]
            match = candidates[0] if len(candidates) == 1 else None
        if match is None:
            unmatched_observations += 1
        else:
            if match['observation_step_id'] is not None:
                raise ValueError('Duplicate observation for one tool call')
            match['observation'] = observation.get('content')
            match['observation_step_id'] = step['step_id']
    return calls, unmatched_observations


def inspect_trace(trace):
    calls, ambiguous = joined_calls(trace)
    model_authors = Counter()
    for step in trace['steps']:
        extra = step.get('extra') or {}
        # Compiled declarations/system instructions do not prove execution.
        if step.get('source') == 'agent' and extra.get('event_type') != 'system_instruction':
            if extra.get('author'):
                model_authors[extra['author']] += 1
    candidate_checks = []
    changed_edit_tools = []
    submissions = []
    for call in calls:
        name = call['function_name']
        observation = decoded(call['observation'])
        observation = observation if isinstance(observation, dict) else {}
        position = {k: call[k] for k in ['step_id', 'call_index', 'author']}
        if name in {'edit_file', 'write_file'} and observation.get('status') == 'ok' and observation.get('diff'):
            changed_edit_tools.append(position)
        if name == 'submit_patch':
            submissions.append({**position, 'observed_status': observation.get('status'),
                                'patch_size': observation.get('patch_size')})
        command = call.get('arguments', {}).get('command', '')
        if name == 'run_command' and re.search(r'\b(?:pytest|unittest|assert)\b', str(command)):
            candidate_checks.append({**position, 'command': command,
                                     'command_sha256': hashlib.sha256(command.encode()).hexdigest(),
                                     'observed_status': observation.get('status'),
                                     'observed_exit_code': observation.get('exit_code')})
    return {'observed_model_events_by_author': dict(model_authors),
            'observed_tool_calls_by_author': dict(Counter(c['author'] or 'unknown' for c in calls)),
            'verify_phase_observed': bool(model_authors.get('bear_verify') or any(c['author'] == 'bear_verify' for c in calls)),
            'draft_phase_observed': bool(model_authors.get('bear_draft') or any(c['author'] == 'bear_draft' for c in calls)),
            'changed_edit_tool_records': changed_edit_tools, 'submissions': submissions,
            'candidate_behavioral_commands_for_review': candidate_checks,
            'unmatched_or_ambiguous_observations': ambiguous,
            'tool_calls_without_matched_observation': sum(c['observation_step_id'] is None for c in calls)}


def inspect(directory):
    manifest_path = directory / 'run_manifest.json'
    manifest = json.loads(manifest_path.read_text())
    records = []
    for policy in manifest['plan']['policies']:
        for task in manifest['plan']['tasks']:
            instance = task['instance_id']
            path = directory / 'results' / policy / 'traces' / ('trace_' + instance + '.json')
            record = {'policy': policy, 'instance_id': instance, 'trace_present': path.is_file()}
            if path.is_file():
                record.update(trace_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                              **inspect_trace(json.loads(path.read_text())))
            records.append(record)
    totals = {}
    for policy in manifest['plan']['policies']:
        selected = [r for r in records if r['policy'] == policy]
        totals[policy] = {'assigned': len(selected), 'traces_present': sum(r['trace_present'] for r in selected),
                          'draft_phase_observed': sum(r.get('draft_phase_observed', False) for r in selected),
                          'verify_phase_observed': sum(r.get('verify_phase_observed', False) for r in selected),
                          'runs_with_candidate_check_commands': sum(bool(r.get('candidate_behavioral_commands_for_review')) for r in selected),
                          'runs_with_observed_nonempty_submission': sum(any(isinstance(s.get('patch_size'), (int, float)) and s['patch_size'] > 0 and s.get('observed_status') == 'ok' for s in r.get('submissions', [])) for r in selected)}
    return {'manifest_sha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
            'records': records, 'totals': totals,
            'interpretation': 'Phase activation only. Candidate commands, exit zero, edit-tool diffs and a nonempty submission are not behavioral correctness or external acceptance. Native commands may edit source and need full review; these edit records are not a complete source-version ledger. Retain all assigned trials.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = inspect(args.directory)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result['totals'], indent=2))


if __name__ == '__main__':
    main()
