#!/usr/bin/env python3
"""Recompute reported arithmetic from the bundled, derived measurements.

This does not rerun model inference or certify the source observations. Full
private traces and licensed competition inputs are intentionally not bundled.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import random
import statistics


def real_check_summary(records):
    """Recompute coverage and judgments while retaining every invocation."""
    identities = [(r['instance_id'], r['policy'], r['check_step']) for r in records]
    if not records or len(set(identities)) != len(records):
        raise ValueError('Missing or duplicate real-check invocation')
    labels = {'frozen_v4_paired', 'assertion_contract_v1_paired'}
    if any(set(r['outcomes']) != labels for r in records):
        raise ValueError('Missing or extra real-check comparator')
    comparators = {}
    for label in sorted(labels):
        values = [r['outcomes'][label] for r in records]
        if any(not math.isfinite(v['measured_seconds']) or v['measured_seconds'] < 0 for v in values):
            raise ValueError('Invalid replay execution cost')
        result = {'cases': len(values),
                  'outer_statuses': dict(Counter(v['status'] for v in values)),
                  'current_child_statuses': dict(Counter(v['current_child_status'] for v in values)),
                  'starting_child_statuses': dict(Counter(v['starting_child_status'] for v in values)),
                  'total_seconds': sum(v['measured_seconds'] for v in values)}
        if label == 'assertion_contract_v1_paired':
            result.update(supported_shape=sum(v['supported_shape'] for v in values),
                          observed_result_link=sum(v['observed_result_link'] for v in values),
                          mechanical_certificates=sum(v['mechanical_certificate'] for v in values))
        comparators[label] = result
    return {'cases': len(records), 'issues': len({r['instance_id'] for r in records}),
            'unique_scripts': len({r['witness_sha256'] for r in records}),
            'identical_outer_judgments': sum(
                r['outcomes']['frozen_v4_paired']['status'] ==
                r['outcomes']['assertion_contract_v1_paired']['status'] for r in records),
            'child_timeouts': sum(v[key] in {'timeout', 'timed_out'} for r in records
                                  for v in r['outcomes'].values()
                                  for key in ['current_child_status', 'starting_child_status']),
            'comparators': comparators}


def paired_statistics(rows, control, candidate):
    outcomes = {(r['instance_id'], r['policy']): r['status'] == 'accepted' for r in rows}
    tasks = sorted({r['instance_id'] for r in rows})
    pairs = [(outcomes[(task, control)], outcomes[(task, candidate)]) for task in tasks]
    counts = Counter(pairs)
    n = len(pairs)
    a, b = counts[(True, False)], counts[(False, True)]
    discordant = a + b
    probability = min(1.0, 2 * sum(math.comb(discordant, i) for i in range(min(a, b) + 1))
                      / 2 ** discordant) if discordant else 1.0
    differences = [int(candidate_pass) - int(control_pass) for control_pass, candidate_pass in pairs]
    rng = random.Random(20261112)
    draws = sorted(sum(rng.choice(differences) for _ in range(n)) / n for _ in range(10000))
    return {'complete_pairs': n,
            'fixed_accepted': sum(control_pass for control_pass, _ in pairs),
            'bear_accepted': sum(candidate_pass for _, candidate_pass in pairs),
            'both_accepted': counts[(True, True)], 'neither_accepted': counts[(False, False)],
            'fixed_only': a, 'bear_only': b,
            'difference_bear_minus_fixed': sum(differences) / n,
            'exploratory_paired_bootstrap_95_percentile': [draws[int(.025 * 9999)], draws[int(.975 * 9999)]],
            'two_sided_exact_mcnemar_p': probability}


def reproduce(measurements):
    result = {'rounds': {}, 'representation': {}, 'qualification': {}}
    for item in measurements['rounds']:
        rows, policies, tasks = item['rows'], item['policies'], item['task_ids']
        assigned = {(task, policy) for task in tasks for policy in policies}
        actual = {(row['instance_id'], row['policy']) for row in rows}
        if len(actual) != len(rows) or assigned != actual:
            raise ValueError('Missing, duplicate, or extra assignment in ' + item['name'])
        if any(row['status'] not in {'accepted', 'rejected', 'agent_no_patch'} for row in rows):
            raise ValueError('Unreviewed or unresolved assignment in ' + item['name'])
        aggregates = {}
        for policy in policies:
            selected = [row for row in rows if row['policy'] == policy]
            entry = {'outcomes': dict(Counter(row['status'] for row in selected)),
                     'empty_patches': sum(row['patch_chars'] == 0 for row in selected),
                     'runtime_operations': sum(row['executed_runtime_operations'] for row in selected)}
            times = [row['agent_phase_seconds_including_setup'] for row in selected]
            if policy in item['recorded_cost_policies']:
                if not times or not all(isinstance(t, (int, float)) and t > 0 for t in times):
                    raise ValueError('Recorded costs lack complete per-trial measurements')
                entry['total_observed_agent_seconds_including_setup'] = sum(times)
                entry['accepted_per_observed_agent_hour'] = 3600 * sum(row['status'] == 'accepted' for row in selected) / sum(times)
            aggregates[policy] = entry
        comparisons = {contrast['name']: paired_statistics(rows, contrast['control'], contrast['candidate'])
                       for contrast in item['contrasts']}
        result['rounds'][item['name']] = {'aggregates': aggregates, 'comparisons': comparisons}

    audit = measurements['representation']
    records = audit['per_task']
    if len({row['instance_id'] for row in records}) != len(records):
        raise ValueError('Duplicate representation audit task')
    overall = {'tasks': len(records), 'graphs': sum(r['graph_present'] for r in records),
               'all_changed_modules_represented': sum(r['all_reference_modules_represented'] for r in records),
               'changed_module_hit_at_10': sum(r['changed_module_hit_at_10'] for r in records)}
    by_repo = {repo: {'tasks': sum(r['repo'] == repo for r in records),
                      'changed_module_hit_at_10': sum(r['changed_module_hit_at_10'] for r in records if r['repo'] == repo)}
               for repo in sorted({r['repo'] for r in records})}
    coverage = {kind: {field: sum(snapshot['coverage'][kind][field] for snapshot in audit['snapshots'])
                       for field in ['source_definitions', 'ids_present_in_graph']}
                for kind in ['class', 'sync_function', 'async_function']}
    result['representation'] = {'overall': overall, 'by_repository': by_repo, 'two_snapshot_coverage': coverage}

    records = measurements['qualification']['tasks']
    result['qualification'] = {'tasks': len(records), 'qualified': sum(r['eligible'] for r in records.values()),
                               'reasons': dict(Counter(r['reason'] for r in records.values())),
                               'by_repository_prefix': {prefix: {'qualified': sum(r['eligible'] for task, r in records.items() if task.split('_')[0] == prefix),
                                                                 'ineligible': sum(not r['eligible'] for task, r in records.items() if task.split('_')[0] == prefix)}
                                                        for prefix in sorted({task.split('_')[0] for task in records})}}
    if 'execution' in measurements:
        execution = {'staged': {}, 'witness': {}}
        for label, rows in measurements['execution']['staged'].items():
            if len({(r['instance_id'], r['policy']) for r in rows}) != len(rows):
                raise ValueError('Duplicate phase measurement')
            aggregates = {}
            for policy in sorted({r['policy'] for r in rows}):
                selected = [r for r in rows if r['policy'] == policy]
                aggregates[policy] = {'assigned': len(selected),
                    'traces_present': sum(r['trace_present'] for r in selected),
                    'draft_phase_observed': sum(r['draft_phase_observed'] for r in selected),
                    'verify_phase_observed': sum(r['verify_phase_observed'] for r in selected)}
            execution['staged'][label] = aggregates
        rows = measurements['execution']['witness']['records']
        if len({(r['instance_id'], r['policy']) for r in rows}) != len(rows):
            raise ValueError('Duplicate witness measurement')
        for policy in sorted({r['policy'] for r in rows}):
            selected = [r for r in rows if r['policy'] == policy]
            statuses = Counter(check.get('current_child_status') or check.get('diagnostic_status') or 'unparsed'
                               for r in selected for check in r['helper_check_calls'])
            execution['witness'][policy] = {'assigned': len(selected),
                'successful_installer_calls': sum(call['status'] == 'success' for r in selected for call in r['installer_calls']),
                'assignments_with_helper_checks': sum(bool(r['helper_check_calls']) for r in selected),
                'helper_check_invocations': sum(len(r['helper_check_calls']) for r in selected),
                'helper_child_statuses': dict(statuses),
                'status_only_queries': sum(len(r['helper_status_queries']) for r in selected),
                'externally_accepted': sum(r['external_status'] == 'accepted' for r in selected),
                'total_agent_seconds_including_setup': sum(r['agent_phase_seconds_including_setup'] or 0 for r in selected)}
        if 'phase_budget' in measurements['execution']:
            execution['phase_budget'] = {}
            for label, rows in measurements['execution']['phase_budget'].items():
                if len({(r['instance_id'], r['policy']) for r in rows}) != len(rows):
                    raise ValueError('Duplicate phase budget measurement')
                totals = {}
                for policy in sorted({r['policy'] for r in rows}):
                    selected = [r for r in rows if r['policy'] == policy]
                    remaining = []
                    for row in selected:
                        first = row['phases']['bear_verify']['first_observed_elapsed_s']
                        value = max(0, row['configured_task_seconds'] - first) if first is not None else None
                        if value != row['remaining_at_first_observed_verifier_event_s']:
                            raise ValueError('Remaining budget arithmetic differs')
                        if value is not None:
                            remaining.append(value)
                    totals[policy] = {
                        'assigned': len(selected),
                        'draft_observed': sum(r['phases']['bear_draft']['observed'] for r in selected),
                        'verifier_observed': sum(r['phases']['bear_verify']['observed'] for r in selected),
                        'no_verifier_and_session_timeout': sum(not r['phases']['bear_verify']['observed']
                            and r['session_timeout_recorded'] for r in selected),
                        'median_remaining_at_first_observed_verifier_event_s': statistics.median(remaining) if remaining else None,
                        'draft_recorded_completion_tokens': sum(r['phases']['bear_draft']['recorded_completion_tokens'] for r in selected),
                        'verify_recorded_completion_tokens': sum(r['phases']['bear_verify']['recorded_completion_tokens'] for r in selected)}
                execution['phase_budget'][label] = totals
        result['execution'] = execution
    if 'real_check_replay' in measurements:
        result['real_check_replay'] = real_check_summary(measurements['real_check_replay'])
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    manifest = json.loads((root / 'bundle_manifest.json').read_text())
    for name, entry in manifest['files'].items():
        path = (root / name).resolve()
        if not path.is_relative_to(root) or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']:
            raise ValueError('Missing or changed bundle file: ' + name)
    measurements = json.loads((root / 'measurements.json').read_text())
    observed = reproduce(measurements)
    expected = json.loads((root / 'expected.json').read_text())
    if observed != expected:
        raise ValueError('Derived arithmetic differs from recorded canonical results')
    if args.output:
        args.output.write_text(json.dumps(observed, indent=2) + '\n')
    print(json.dumps({'all_bundle_hashes_match': True, 'canonical_arithmetic_matches': True,
                      'complete_rounds': len(observed['rounds']),
                      'reused_development_assignments': sum(len(r['rows']) for r in measurements['rounds']),
                      'public_audit_tasks': observed['representation']['overall']['tasks'],
                      'qualified_tasks': observed['qualification']['qualified'],
                      'real_check_replay': observed.get('real_check_replay'),
                      'scope': 'Arithmetic reproduction from derived records; not model reruns, independent annotation, or evidence of general repair superiority.'}, indent=2))


if __name__ == '__main__':
    main()
