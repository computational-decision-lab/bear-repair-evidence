# bearcheck 0.3.3: reusable partial check diagnostics

This is a prepared source package, not a published release. It provides a small
Python API, CLI and versioned JSON schema around the frozen BEAR assertion
contract. Python 3.10+ and Git suffice for execution. No model, credentials,
Kaggle access, third-party Python runtime dependency or official data is needed.

Unzip the resource and run from its root without installation:

```bash
python -m bearcheck --help
python reproduce.py
python examples/assertion_contract_demo.py
python -m unittest discover -s tests -p test_assertion_contract.py -v
python scripts/run_evidence_conformance.py --output results/my_conformance.json
```

An optional local installation uses your existing build tools:

```bash
python -m pip install --no-deps --no-build-isolation .
bearcheck /tmp/check.py --repository /path/to/git-root --state /tmp/check-ledger
```

No install is needed in an offline environment. A source install requires an
already installed setuptools version 40.8 or later and wheel. There is no claimed PyPI
package, release URL or DOI.

## Stable API and record

```python
from bearcheck import diagnose

record = diagnose('/path/to/git-root', '/tmp/check.py', '/tmp/check-ledger')
print(record['status'])
print(record['mechanical_certificate'])
assert record['semantic_relevance'] == 'unassessed'
```

The repository must be the worktree root, with the intended starting source
committed as HEAD. State belongs outside the worktree. Otherwise Git and
filesystem errors are ordinary API exceptions; the CLI returns 2 for such input
errors. Exit code 0 means a diagnostic record was emitted. It never means the
patch is correct. Current-only mode is available, but cannot certify a starting
version transition. Schema: `bearcheck/schemas/record-v1.schema.json`. The schema
checks structure only. Read `status`, child faults and limitations together.

The package contains the exact implementation bytes used in the registered
64-case comparison, with SHA256 identities in
`bearcheck/implementation_manifest.json`. This packaging does not change the
candidate used in any running experiment. The original standalone API remains
available under `architecture/` for compatibility and reproduction.

## What evidence is established

The helper freezes check bytes, executes current and fresh HEAD source, records
source function calls, checks source stability, and requires an executed,
nonliteral assertion with a partial syntactic dependency on an observed call.
Straight-line name assignments/aliases are supported; helpers, control flow,
mutation forms and reflection cause conservative abstention.

| Designed category | Cases | Frozen v4 certificates | Added contract certificates |
| --- | ---: | ---: | ---: |
| Supported positive forms | 16 | 16 | 16 |
| Explicit mechanical negatives | 36 | 16 | 0 |
| Known limits / unsupported forms | 12 | 12 | 8 |

These are four related typed-return families crossed with sixteen designed
templates, not 64 independent repairs or an accuracy/prevalence estimate. Keep
all three rows. Wrong requirements and algebraic cancellation still certify;
valid helper-based checks abstain. A partial syntax path is not semantic
dependence, causality or intent. Same-line call attribution can conflate calls.
No general soundness, completeness, repair gain or throughput gain is asserted.

## Integration and boundaries

An agent may use the record as feedback, then inspect the actual source diff and
run independent tests. In experiment analysis, separate tool delivery, attempted
calls, successful execution, a mechanical certificate and independent repair
acceptance. Preserve all assigned runs, including unused tools and failures.
The tool never receives reference patches or external acceptance labels.

Checks execute ordinary Python with caller permissions in the existing sandbox.
They may have side effects. This tool is not a sandbox, rollback mechanism or
security boundary. HEAD extraction omits untracked build assets. Native code,
asynchronous execution, data mutation and environment-specific dependencies can
require additional analysis. Each child has an eight-second timeout.

Established test-oracle and slicing work includes Huo and Clause's
*Improving Oracle Quality by Detecting Brittle Assertions and Unused Inputs in
Tests* (FSE 2014), as well as Agentless, SWT-Bench and AssertFlip. The reusable
contribution is the lightweight versioned diagnostic contract, executable
counterexamples and recorded abstentions; slicing and fail-to-pass are not new.

## License, citation and reproduction

Code and generic fixtures are Apache-2.0. `CITATION.cff` identifies this version.
The archive manifest verifies every payload. The source contains no official
issues, reference fixes, hidden tests, third-party repositories, private model
traces, weights or credentials. Existing independent CPU reproduction checks all
64 decisions, plan/source hashes, seven subprocess tests and the generic demo;
it does not rerun repairs or supply independent annotation. Host-dependent
timings need not match. No outside adoption or citation count is claimed.
