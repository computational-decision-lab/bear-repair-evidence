"""Conservative, syntactic assertion-result linkage for small Python reproducers.

This is a partial backward slice, not dynamic taint or proof of causality. It
abstains on control-flow, mutation, reflection, and user helper definitions.
"""
from __future__ import annotations

import ast


def lines(node):
    return set(range(node.lineno, (getattr(node, 'end_lineno', None) or node.lineno) + 1))


def analyse(source):
    tree = ast.parse(source)
    assignments = {}
    assertions = []
    unsupported = []
    forbidden = {'eval', 'exec', 'globals', 'locals', 'compile', '__import__', 'setattr', 'delattr'}
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in forbidden:
            unsupported.append('reflection:' + node.func.id)
        if isinstance(node, (ast.NamedExpr, ast.AugAssign, ast.Delete)):
            unsupported.append(type(node).__name__)
    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            if isinstance(node, ast.ImportFrom) and any(alias.name == '*' for alias in node.names):
                unsupported.append('wildcard_import')
            continue
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            if len(targets) != 1 or not isinstance(targets[0], ast.Name) or node.value is None:
                unsupported.append('non_name_assignment')
                continue
            name = targets[0].id
            # Slice each definition in source order. Later overwrites do not
            # rewrite an earlier alias's provenance.
            assignments[name] = dependencies(node.value, assignments)
        elif isinstance(node, ast.Assert):
            dep = dependencies(node.test, assignments)
            literal = False
            try:
                literal = bool(ast.literal_eval(node.test))
            except (ValueError, TypeError, SyntaxError):
                pass
            assertions.append({'line': node.lineno, 'test_lines': sorted(lines(node.test)),
                               'call_lines': sorted(dep), 'literal_truth': literal})
        elif isinstance(node, ast.Expr):
            # Standalone calls are observed but do not contribute to a later
            # assertion's syntactic input dependencies.
            if not isinstance(node.value, (ast.Call, ast.Constant)):
                unsupported.append('expression:' + type(node.value).__name__)
        else:
            unsupported.append(type(node).__name__)
    return {'supported_shape': not unsupported, 'unsupported_shapes': sorted(set(unsupported)),
            'assertions': assertions,
            'limitation': 'Syntactic result linkage only. Aliasing through mutation, helper/control flow, native calls, implicit state and semantic cancellation require separate analysis.'}


def dependencies(node, assignments):
    result = set()
    for item in ast.walk(node):
        if isinstance(item, ast.Call):
            result.update(lines(item))
        elif isinstance(item, ast.Name) and isinstance(item.ctx, ast.Load):
            result.update(assignments.get(item.id, set()))
    return result


def interpret(static, current):
    executed = set(current.get('executed_assertion_lines', []))
    source_lines = set(current.get('source_witness_call_lines', []))
    executed_assertions = [row for row in static['assertions'] if row['line'] in executed]
    linked = [row['line'] for row in executed_assertions
              if not row['literal_truth'] and source_lines.intersection(row['call_lines'])]
    return {'supported_shape': static['supported_shape'],
            'unsupported_shapes': static['unsupported_shapes'],
            'executed_assertion_count': len(executed_assertions),
            'linked_assertion_lines': linked,
            'nonliteral_source_result_link_observed': bool(linked) and static['supported_shape'],
            'limitation': static['limitation']}
