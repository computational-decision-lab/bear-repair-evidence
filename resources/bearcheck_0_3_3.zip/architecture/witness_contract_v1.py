"""Optional assertion contract layered over the frozen witness-v4 diagnostics.

The contract supplies a narrower mechanical observation, not issue relevance
or proof that an agent patch is correct. Existing model trials keep v4 unchanged.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
_slice_spec = importlib.util.spec_from_file_location('bear_assertion_contract', HERE / 'assertion_contract.py')
_slice_module = importlib.util.module_from_spec(_slice_spec)
_slice_spec.loader.exec_module(_slice_module)
analyse, interpret = _slice_module.analyse, _slice_module.interpret


def legacy_module():
    spec = importlib.util.spec_from_file_location('isolated_legacy_witness', HERE / 'witness_ledger_v4.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def instrumented_child(legacy):
    child = legacy.CHILD
    child = child.replace('sites = set()', 'sites = set()\nsource_witness_call_lines = set()\nexecuted_assertion_lines = set()')
    before = 'def trace(frame, event, arg):'
    after = '''def witness_trace(frame, event, arg):
    if event == 'line' and frame.f_lineno in cfg['assert_lines']:
        executed_assertion_lines.add(frame.f_lineno)
    return witness_trace
def trace(frame, event, arg):
    if frame.f_code.co_filename == cfg['witness']:
        return witness_trace
'''
    if child.count(before) != 1:
        raise ValueError('Frozen v4 child layout changed')
    child = child.replace(before, after)
    child = child.replace('sites.add((str(path), frame.f_code.co_name))',
                          'sites.add((str(path), frame.f_code.co_name))\n                source_witness_call_lines.add(parent.f_lineno)')
    marker = "'source_function_site_count': len(sites), 'workspace_module_origins': origins[:24]}))"
    replacement = "'source_function_site_count': len(sites), 'workspace_module_origins': origins[:24],\n    'executed_assertion_lines': sorted(executed_assertion_lines),\n    'source_witness_call_lines': sorted(source_witness_call_lines)}))"
    if child.count(marker) != 1:
        raise ValueError('Frozen v4 output layout changed')
    return child.replace(marker, replacement)


def evaluate(root, state, witness, compare_baseline=True):
    start = time.monotonic()
    root, state, witness = Path(root).resolve(), Path(state).resolve(), Path(witness).resolve()
    legacy = legacy_module()
    child = instrumented_child(legacy)
    original_execute = legacy.execute
    child_calls = []

    def execute(root, frozen, timeout=8):
        import ast
        tree = ast.parse(frozen.read_text())
        assert_lines = [n.lineno for n in ast.walk(tree) if isinstance(n, ast.Assert)]
        if not assert_lines:
            return {'status': 'invalid_check', 'diagnostic': 'Use an explicit assert of expected behavior.'}
        call_lines = sorted({line for n in ast.walk(tree) if isinstance(n, ast.Call)
                             for line in range(n.lineno, (n.end_lineno or n.lineno) + 1)})
        t0 = time.monotonic()
        try:
            process = subprocess.run([sys.executable, '-I', '-c', child],
                input=json.dumps({'root': str(root), 'witness': str(frozen),
                                  'assert_lines': assert_lines, 'call_lines': call_lines}),
                text=True, capture_output=True, timeout=timeout,
                env={k: v for k, v in os.environ.items() if k != 'PYTHONPATH'})
            if process.returncode:
                outcome = {'status': 'runner_error', 'diagnostic': process.stderr[-2400:]}
            else:
                try:
                    outcome = json.loads(process.stdout)
                except ValueError:
                    outcome = {'status': 'runner_error', 'diagnostic': (process.stdout + process.stderr)[-2400:]}
        except subprocess.TimeoutExpired:
            outcome = {'status': 'timed_out', 'diagnostic': 'Child execution timed out.'}
        child_calls.append({'seconds': time.monotonic() - t0, 'status': outcome['status']})
        return outcome

    # This module instance belongs only to this invocation. The frozen v4
    # module, source and all other callers are untouched.
    legacy.execute = execute
    record = legacy.evaluate(root, state, witness, compare_baseline=compare_baseline)
    legacy.execute = original_execute
    try:
        static = analyse(witness.read_text())
    except (SyntaxError, UnicodeError):
        static = {'supported_shape': False, 'unsupported_shapes': ['invalid_syntax'], 'assertions': [],
                  'limitation': 'Invalid check cannot establish an assertion contract.'}
    contract = interpret(static, record.get('current') or {})
    legacy_status = record['status']
    mechanically_eligible = (legacy_status == 'sensitive_transition'
                            and contract['nonliteral_source_result_link_observed'])
    if legacy_status == 'sensitive_transition' and not mechanically_eligible:
        status = 'assertion_link_unproven'
    else:
        status = legacy_status
    result = {**record, 'schema': 'bear-check/assertion-contract/v1',
              'legacy_status': legacy_status, 'status': status,
              'assertion_contract': contract,
              'mechanical_certificate': mechanically_eligible,
              'child_executions': child_calls, 'total_seconds': time.monotonic() - start,
              'checked_utc': datetime.now(timezone.utc).isoformat(),
              'implementation_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'semantic_relevance': 'unassessed',
              'limitation': 'A mechanical certificate is a partial syntactic/execution check, not causal proof, semantic issue relevance, repair correctness or hidden-test acceptance.'}
    state.mkdir(parents=True, exist_ok=True)
    with (state / 'contracts.jsonl').open('a') as handle:
        handle.write(json.dumps(result) + '\n')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('witness', type=Path)
    parser.add_argument('--repository', type=Path, default=Path.cwd())
    parser.add_argument('--state', type=Path, required=True)
    parser.add_argument('--current-only', action='store_true')
    args = parser.parse_args()
    print(json.dumps(evaluate(args.repository, args.state, args.witness,
                              compare_baseline=not args.current_only), indent=2))


if __name__ == '__main__':
    main()
