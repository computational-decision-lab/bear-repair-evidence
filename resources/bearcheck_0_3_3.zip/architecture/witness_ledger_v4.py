"""Sandbox-only, source-bound behavioral checks with an optional HEAD control.

This checks mechanical sensitivity, execution origin and freshness. It cannot
decide whether an assertion expresses the user's intended behavior.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import time


CHILD = r'''
import contextlib, importlib.machinery, io, json, os, pathlib, runpy, sys, traceback
cfg = json.loads(sys.stdin.read())
root = pathlib.Path(cfg['root']).resolve()
os.chdir(root)
sys.path[:0] = [str(root / 'src'), str(root)]
sites = set()
root_prefix = str(root) + os.sep
source_paths = {}
original_get_code = importlib.machinery.SourceFileLoader.get_code
def fresh_repository_code(loader, fullname):
    filename = loader.get_filename(fullname)
    if filename.startswith(root_prefix) and filename.endswith('.py'):
        # Same-size edits within one timestamp second can reuse stale pyc even
        # in a fresh interpreter. Compile repository bytes directly; -B alone
        # only prevents writing caches and does not prevent reading old ones.
        return loader.source_to_code(loader.get_data(filename), filename)
    return original_get_code(loader, fullname)
importlib.machinery.SourceFileLoader.get_code = fresh_repository_code
def trace(frame, event, arg):
    # Only global call events are needed. Returning a local line tracer for
    # every dependency frame made real Requests imports exceed the timeout.
    filename = frame.f_code.co_filename
    if event != 'call' or frame.f_code.co_name == '<module>' or not filename.startswith(root_prefix):
        return None
    if filename not in source_paths:
        try:
            source_paths[filename] = pathlib.Path(filename).resolve().relative_to(root)
        except (ValueError, OSError):
            source_paths[filename] = None
    path = source_paths[filename]
    if path is None or 'tests' in path.parts or path.name.startswith('test_'):
        return None
    parent = frame.f_back
    while parent is not None:
        if parent.f_code.co_filename == cfg['witness']:
            if parent.f_lineno in cfg['call_lines']:
                sites.add((str(path), frame.f_code.co_name))
            break
        parent = parent.f_back
    return None
output, errors = io.StringIO(), io.StringIO()
status, exception, diagnostic, witness_assertion = 'passed', None, '', False
source_api_exception = False
sys.settrace(trace)
try:
    with contextlib.redirect_stdout(output), contextlib.redirect_stderr(errors):
        runpy.run_path(cfg['witness'], run_name='__main__')
except BaseException as exc:
    status, exception = 'failed', type(exc).__name__
    frames = traceback.extract_tb(exc.__traceback__)
    diagnostic = ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))[-2400:]
    witness_assertion = (isinstance(exc, AssertionError) and bool(frames)
        and pathlib.Path(frames[-1].filename).resolve() == pathlib.Path(cfg['witness']).resolve()
        and frames[-1].lineno in cfg['assert_lines'])
    # A valid reproducer may raise inside the real API before reaching its
    # final assert. Keep this distinct from a witness-local assertion, import
    # initialization, runner errors, and a local exception after an unused call.
    call_from_witness = any(pathlib.Path(f.filename).resolve() == pathlib.Path(cfg['witness']).resolve()
        and f.lineno in cfg['call_lines'] for f in frames)
    if frames and call_from_witness and isinstance(exc, Exception) and not isinstance(
            exc, (ImportError, SyntaxError, IndentationError)):
        origin = pathlib.Path(frames[-1].filename).resolve()
        try:
            relative_origin = origin.relative_to(root)
        except ValueError:
            relative_origin = None
        source_api_exception = (relative_origin is not None
            and frames[-1].name != '<module>' and 'tests' not in relative_origin.parts
            and not relative_origin.name.startswith('test_'))
finally:
    sys.settrace(None)
origins = []
for name, module in list(sys.modules.items()):
    filename = getattr(module, '__file__', None)
    if not filename:
        continue
    try:
        relative = pathlib.Path(filename).resolve().relative_to(root)
    except (ValueError, OSError):
        continue
    origins.append({'module': name, 'path': str(relative)})
print(json.dumps({'status': status, 'exception': exception,
    'witness_assertion_failed': witness_assertion,
    'repository_api_exception': source_api_exception, 'diagnostic': diagnostic,
    'stdout_tail': output.getvalue()[-900:], 'stderr_tail': errors.getvalue()[-900:],
    'source_function_sites': [list(s) for s in sorted(sites)[:24]],
    'source_function_site_count': len(sites), 'workspace_module_origins': origins[:24]}))
'''


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], stderr=subprocess.PIPE)


def version(root):
    digest = hashlib.sha256(git(root, 'rev-parse', 'HEAD'))
    digest.update(git(root, 'diff', '--binary', 'HEAD'))
    for name in sorted(git(root, 'ls-files', '-z', '--others', '--exclude-standard').split(b'\0')):
        if not name:
            continue
        path = root / os.fsdecode(name)
        if path.is_file() and path.suffix in {'.py', '.json', '.yaml', '.yml', '.toml'}:
            digest.update(name)
            digest.update(path.read_bytes())
    return digest.hexdigest()


def execute(root, witness, timeout=8):
    tree = ast.parse(witness.read_text())
    lines = [node.lineno for node in ast.walk(tree) if isinstance(node, ast.Assert)]
    call_lines = sorted({line for node in ast.walk(tree) if isinstance(node, ast.Call)
                         for line in range(node.lineno, (node.end_lineno or node.lineno) + 1)})
    if not lines:
        return {'status': 'invalid_check', 'diagnostic': 'Use an explicit assert of expected behavior.'}
    try:
        result = subprocess.run([sys.executable, '-I', '-c', CHILD],
            input=json.dumps({'root': str(root), 'witness': str(witness),
                              'assert_lines': lines, 'call_lines': call_lines}),
            text=True, capture_output=True, timeout=timeout,
            env={k: v for k, v in os.environ.items() if k != 'PYTHONPATH'})
    except subprocess.TimeoutExpired:
        return {'status': 'timed_out', 'diagnostic': 'Use a small offline check without a server or network request.'}
    if result.returncode:
        return {'status': 'runner_error', 'diagnostic': result.stderr[-2400:]}
    try:
        return json.loads(result.stdout)
    except ValueError:
        return {'status': 'runner_error', 'diagnostic': (result.stdout + result.stderr)[-2400:]}


def evaluate(root, state, witness, compare_baseline=True):
    started = time.monotonic()
    root, state, witness = root.resolve(), state.resolve(), witness.resolve()
    state.mkdir(parents=True, exist_ok=True)
    source = witness.read_bytes()
    try:
        ast.parse(source)
    except (SyntaxError, UnicodeError) as exc:
        return {'status': 'invalid_check', 'diagnostic': str(exc),
                'next': 'Correct the check syntax; this is not a behavioral failure.'}
    witness_sha = hashlib.sha256(source).hexdigest()
    frozen = state / (witness_sha + '.py')
    if not frozen.exists():
        frozen.write_bytes(source)
    elif frozen.read_bytes() != source:
        raise ValueError('Frozen witness bytes changed')
    before = version(root)
    current = execute(root, frozen)
    baseline = None
    if compare_baseline:
        head = git(root, 'rev-parse', 'HEAD').decode().strip()
        # A new snapshot for every check prevents witness side effects from
        # contaminating the next HEAD control.
        with tempfile.TemporaryDirectory(prefix='head-', dir=state) as temporary:
            baseline_root = Path(temporary)
            # HEAD contains the submitted starting source, not a reference fix.
            # This costs sandbox time and never accesses external test labels.
            with tarfile.open(fileobj=io.BytesIO(git(root, 'archive', 'HEAD'))) as archive:
                archive.extractall(baseline_root, filter='data')
            baseline = execute(baseline_root, frozen)
    after = version(root)
    grounded = bool(current.get('source_function_site_count'))
    baseline_grounded = baseline is not None and bool(baseline.get('source_function_site_count'))
    baseline_failure_kind = None
    if baseline_grounded and baseline.get('witness_assertion_failed'):
        baseline_failure_kind = 'witness_assertion'
    elif baseline_grounded and baseline.get('repository_api_exception'):
        baseline_failure_kind = 'repository_api_exception'
    sensitive = baseline_failure_kind is not None
    fresh = before == after
    if not fresh:
        status, action = 'source_changed_during_check', 'Inspect the check side effects and rerun after source is stable.'
    elif current['status'] in {'timed_out','runner_error','invalid_check'} or current.get('exception') in {'ImportError','ModuleNotFoundError','SyntaxError','IndentationError'}:
        status, action = 'check_execution_failed', 'Correct the reported check import, syntax or timeout fault. It is not a behavioral verification result.'
    elif not grounded:
        status, action = 'disconnected_check', 'Import and call the real repository API, rather than copying its logic.'
    elif compare_baseline and not sensitive:
        status, action = 'not_demonstrated_sensitive', 'The HEAD control neither fails a witness assertion nor raises from a repository API call. Inspect the actual caller or improve the check; do not infer a fix.'
    elif current['status'] == 'passed':
        status = 'sensitive_transition' if compare_baseline else 'current_check_passed'
        action = 'Inspect the source diff and targeted existing tests, then submit if the original contract is satisfied.'
    else:
        status, action = 'behavior_still_fails', 'Use the observed failure to inspect the root cause, edit source and rerun this exact frozen witness.'
    record = {'helper_version': 4, 'status': status, 'witness_sha256': witness_sha,
        'source_version_before': before, 'source_version_after': after,
        'source_stable_during_check': fresh, 'compare_baseline': compare_baseline,
        'current': current, 'baseline': baseline,
        'baseline_failure_kind': baseline_failure_kind, 'next': action,
        'seconds': time.monotonic() - started,
        'limitation': 'These are partial execution and sensitivity diagnostics, not proof of issue relevance or hidden-test acceptance. Dependency-origin exceptions require separate review.'}
    with (state / 'checks.jsonl').open('a') as handle:
        handle.write(json.dumps(record) + '\n')
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['check', 'recheck', 'status'])
    parser.add_argument('witness', nargs='?')
    args = parser.parse_args()
    root = Path(git(Path.cwd(), 'rev-parse', '--show-toplevel').decode().strip())
    base = Path(tempfile.gettempdir()) / 'bear-witness-state'
    state = base / hashlib.sha256(str(root).encode()).hexdigest()[:16]
    settings = Path(__file__).with_name('bear_witness_settings.json')
    compare = json.loads(settings.read_text())['compare_baseline']
    if args.operation == 'status':
        log = state / 'checks.jsonl'
        if not log.exists():
            print(json.dumps({'status': 'no_check', 'next': 'Create a short Python assertion using the real repository API, then check its path.'}))
            return
        last = json.loads(log.read_text().splitlines()[-1])
        print(json.dumps({'status': last['status'], 'fresh': last['source_version_after'] == version(root),
                          'witness_sha256': last['witness_sha256'], 'next': last['next']}))
        return
    if args.operation == 'recheck':
        if not (state / 'checks.jsonl').exists():
            print(json.dumps({'status': 'no_check', 'next': 'Run check with a Python witness path first.'}))
            return
        previous = json.loads((state / 'checks.jsonl').read_text().splitlines()[-1])
        witness = state / (previous['witness_sha256'] + '.py')
    else:
        if not args.witness:
            parser.error('check requires a Python witness file path')
        witness = Path(args.witness)
    print(json.dumps(evaluate(root, state, witness, compare)))


if __name__ == '__main__':
    main()
