"""Partial diagnostics; a mechanical certificate never proves repair correctness."""
from pathlib import Path
import subprocess

__version__ = "0.3.3"
__all__ = ["diagnose", "__version__"]


def diagnose(repository, check, state, *, compare_baseline=True):
    """Diagnose a Python check against current and optionally starting Git source.

    ``repository`` must name a Git worktree root. ``state`` must be outside
    that worktree so diagnostic output cannot alter its source fingerprint.
    The check executes with caller permissions; use an existing sandbox.
    The returned record explicitly leaves semantic relevance unassessed.
    Filesystem/Git failures raise their ordinary exceptions.
    """
    root, witness, ledger = (Path(p).resolve() for p in (repository, check, state))
    if ledger.is_relative_to(root):
        raise ValueError("Place diagnostic state outside the repository worktree")
    actual_root = Path(subprocess.check_output(
        ["git", "-C", str(root), "rev-parse", "--show-toplevel"],
        stderr=subprocess.PIPE, text=True).strip()).resolve()
    if actual_root != root:
        raise ValueError("repository must be the Git worktree root")
    from ._impl.witness_contract_v1 import evaluate
    return evaluate(root, ledger, witness, compare_baseline=compare_baseline)
