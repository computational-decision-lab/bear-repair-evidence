"""Emit a versioned diagnostic JSON record, never a patch-acceptance verdict."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

from . import __version__, diagnose


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("check", type=Path, help="Python script with explicit assertions")
    parser.add_argument("--repository", required=True, type=Path, help="Git worktree root")
    parser.add_argument("--state", required=True, type=Path, help="Ledger outside the worktree")
    parser.add_argument("--current-only", action="store_true")
    parser.add_argument("--version", action="version", version=__version__)
    args = parser.parse_args()
    try:
        record = diagnose(args.repository, args.check, args.state,
                          compare_baseline=not args.current_only)
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        print(json.dumps({"error": type(exc).__name__, "message": str(exc)}), file=sys.stderr)
        return 2
    print(json.dumps(record, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
