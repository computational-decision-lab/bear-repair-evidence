"""Show additional diagnostics and their remaining failure modes, offline."""
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('demo_contract', ROOT / 'architecture/witness_contract_v1.py')
contract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(contract)


def main():
    observed = {}
    cases = {
        'valid_api_return': 'assert value() == 2\n',
        'ignored_result': 'value()\nother = 2\nassert other == 2\n',
        'skipped_assertion': 'value()\nif False:\n    assert value() == 2\n',
        'algebraic_cancellation_limit': 'x = value()\nassert x - x == 0\n',
        'wrong_requirement_limit': 'assert value() == 2\n',
    }
    with tempfile.TemporaryDirectory(prefix='bear_contract_demo_') as tmp:
        top = Path(tmp)
        root = top / 'repo'
        (root / 'src/demo').mkdir(parents=True)
        (root / 'src/demo/__init__.py').write_text('from .api import value\n')
        path = root / 'src/demo/api.py'
        path.write_text('def value():\n    raise ValueError("starting API failure")\n')
        subprocess.run(['git', 'init', '-q', str(root)], check=True)
        subprocess.run(['git', '-C', str(root), 'add', '.'], check=True)
        subprocess.run(['git', '-C', str(root), '-c', 'user.name=Example', '-c',
                        'user.email=example@localhost', 'commit', '-qm', 'example'], check=True)
        path.write_text('def value():\n    return 2\n')
        for name, body in cases.items():
            witness = top / (name + '.py')
            witness.write_text('from demo import value\n' + body)
            row = contract.evaluate(root, top / 'evidence', witness)
            observed[name] = {key: row[key] for key in ['status', 'legacy_status', 'mechanical_certificate', 'semantic_relevance']}
    expected = {'valid_api_return': True, 'ignored_result': False, 'skipped_assertion': False,
                'algebraic_cancellation_limit': True, 'wrong_requirement_limit': True}
    assert {name: row['mechanical_certificate'] for name, row in observed.items()} == expected
    print(json.dumps({'observed': observed, 'all_expected': True,
                      'limitation': 'The wrong-requirement case has the same executable inputs as the valid case. Intended semantics are not observable from this tool alone.'}, indent=2))


if __name__ == '__main__':
    main()
