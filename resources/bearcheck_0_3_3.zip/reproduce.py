#!/usr/bin/env python3
"""One-command offline rerun of the complete designed diagnostic resource."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    destination = args.output or root / 'reproduction_result.json'
    if destination.exists():
        raise FileExistsError('Preserve earlier reproduction records; select a new --output')
    manifest = json.loads((root / 'manifest.json').read_text())
    for name, entry in manifest['files'].items():
        path = (root / name).resolve()
        assert path.is_relative_to(root) and path.is_file(), name
        raw = path.read_bytes()
        assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256'], name
    with tempfile.TemporaryDirectory(prefix='bearcheck_reproduction_') as temporary:
        top = Path(temporary)
        study = top / 'conformance.json'
        subprocess.run([sys.executable, str(root / 'scripts/run_evidence_conformance.py'),
                        '--output', str(study)], cwd=root, check=True, capture_output=True, text=True)
        actual = json.loads(study.read_text())
        expected = json.loads((root / 'results/evidence_contract_v1/conformance_v1.json').read_text())
        for key in ['categories', 'case_templates', 'all_cases', 'families']:
            assert actual['summary'][key] == expected['summary'][key], key
        assert actual['source_sha256'] == expected['source_sha256']
        assert actual['plan_sha256'] == expected['plan_sha256']
        tests = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests',
            '-p', 'test_assertion_contract.py', '-v'], cwd=root, capture_output=True, text=True, check=True)
        demo = subprocess.run([sys.executable, str(root / 'examples/assertion_contract_demo.py')],
                              cwd=root, capture_output=True, text=True, check=True)
        assert json.loads(demo.stdout)['all_expected']
        repo = top / 'repo'
        repo.mkdir()
        (repo / 'demo.py').write_text('def value():\n    return 1\n')
        for command in [['init', '-q'], ['add', '.'], ['-c', 'user.name=Resource fixture',
                        '-c', 'user.email=fixture@localhost', 'commit', '-qm', 'starting source']]:
            subprocess.run(['git', '-C', str(repo), *command], check=True, capture_output=True)
        (repo / 'demo.py').write_text('def value():\n    return 2\n')
        check = top / 'check.py'
        check.write_text('from demo import value\nassert value() == 2\n')
        cli = subprocess.run([sys.executable, '-m', 'bearcheck', str(check), '--repository',
            str(repo), '--state', str(top / 'ledger')], cwd=root, capture_output=True, text=True, check=True)
        diagnostic = json.loads(cli.stdout)
        assert diagnostic['mechanical_certificate'] and diagnostic['semantic_relevance'] == 'unassessed'
        assert diagnostic['schema'] == 'bear-check/assertion-contract/v1'
        result = {'checked_utc': datetime.now(timezone.utc).isoformat(),
            'payload_hashes_verified': len(manifest['files']), 'registered_cases_rerun': len(actual['records']),
            'all_decision_tables_match': True, 'source_and_plan_hashes_match': True,
            'diagnostic_tests_passed': 7, 'generic_demo_passed': True, 'package_cli_integration_passed': True,
            'mechanical_record_semantics_retained': True, 'model_calls': 0,
            'local_costs': expected['summary']['costs'], 'recomputed_costs': actual['summary']['costs'],
            'python': sys.version,
            'scope': 'Offline rerun of designed related diagnostic cases. No independent annotation, model repair rerun, semantic oracle or repair superiority claim.'}
        assert 'Ran 7 tests' in tests.stderr and tests.stderr.rstrip().endswith('OK')
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
