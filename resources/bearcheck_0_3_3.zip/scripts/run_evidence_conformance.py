#!/usr/bin/env python3
"""Run the frozen, data-free diagnostic conformance matrix; never infer repair gain."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def source(value, exception=False):
    return 'def value():\n' + ('    raise ValueError("synthetic starting API fault")\n'
                               if exception else '    return ' + repr(value) + '\n')


def fixture(family, template):
    old, correct, wrong = {'integer_return': (1, 2, 3),
                          'string_return': ('old', 'new', 'wrong'),
                          'list_return': ([1], [2], [3]),
                          'mapping_return': ({'key': 1}, {'key': 2}, {'key': 3})}[family]
    start = source(old)
    final = source(correct)
    statement = 'from demo import value\n'
    expected = repr(correct)
    if template == 'direct_assertion':
        statement += 'assert value() == ' + expected + '\n'
    elif template == 'assigned_result':
        statement += 'observed = value()\nassert observed == ' + expected + '\n'
    elif template == 'aliased_result':
        statement += 'observed = value()\nalias = observed\nobserved = None\nassert alias == ' + expected + '\n'
    elif template == 'api_exception_repair':
        start = source(old, exception=True)
        statement += 'assert value() == ' + expected + '\n'
    elif template == 'copied_logic':
        statement += 'def copied():\n    return ' + expected + '\nassert copied() == ' + expected + '\n'
    elif template == 'unaffected_behavior':
        statement += 'assert type(value()).__name__ == ' + repr(type(correct).__name__) + '\n'
    elif template == 'ignored_api_result':
        start = source(old, exception=True)
        statement += 'value()\nother = ' + expected + '\nassert other == ' + expected + '\n'
    elif template == 'literal_assertion_after_api_exception':
        start = source(old, exception=True)
        statement += 'value()\nassert True\n'
    elif template == 'skipped_assertion_after_api_exception':
        start = source(old, exception=True)
        statement += 'value()\nif False:\n    assert value() == ' + expected + '\n'
    elif template == 'same_line_unused_result':
        start = source(old, exception=True)
        statement += 'value(); assert 1 == 1\n'
    elif template == 'local_exception':
        statement += 'value()\nraise ValueError("fault in the check, not API")\nassert True\n'
    elif template == 'import_fault':
        statement = 'from demo import missing\nassert missing() == ' + expected + '\n'
    elif template == 'source_side_effect':
        statement += 'observed = value()\nfrom pathlib import Path\nPath("src/demo/api.py").write_text(' + repr(source(wrong)) + ')\nassert observed == ' + expected + '\n'
    elif template == 'semantic_wrong_requirement':
        final = source(wrong)
        statement += 'assert value() == ' + repr(wrong) + '\n'
    elif template == 'algebraically_cancelled_result':
        start = source(old, exception=True)
        statement += 'observed = value()\nassert len(str(observed)) - len(str(observed)) == 0\n'
    elif template == 'helper_function_unsupported':
        statement += 'def obtain():\n    return value()\nassert obtain() == ' + expected + '\n'
    else:
        raise ValueError(template)
    return {'starting_source': start, 'current_source': final, 'witness': statement,
            'issue_intended_value': correct, 'current_implements_intended_value': template != 'semantic_wrong_requirement'}


def initialise(root, code):
    (root / 'src/demo').mkdir(parents=True)
    (root / 'src/demo/__init__.py').write_text('from .api import value\n')
    (root / 'src/demo/api.py').write_text(code)
    subprocess.run(['git', 'init', '-q', str(root)], check=True, capture_output=True)
    subprocess.run(['git', '-C', str(root), 'add', '.'], check=True, capture_output=True)
    subprocess.run(['git', '-C', str(root), '-c', 'user.name=Conformance', '-c',
                    'user.email=conformance@localhost', 'commit', '-qm', 'starting source'],
                   check=True, capture_output=True)


def summarize(records, plan):
    by_template = {}
    for template in plan['cases_per_family']:
        selected = [r for r in records if r['template'] == template]
        by_template[template] = {'cases': len(selected), 'category': selected[0]['category'],
            'accepted': {name: sum(r['decisions'][name] for r in selected) for name in plan['comparators']},
            'new_statuses': dict(Counter(r['contract']['status'] for r in selected))}
    categories = {}
    for category in ['supported_positive', 'mechanical_negative', 'explicit_limit']:
        selected = [r for r in records if r['category'] == category]
        categories[category] = {'cases': len(selected),
            'accepted': {name: sum(r['decisions'][name] for r in selected) for name in plan['comparators']}}
    cost = {name: {'median_seconds': statistics.median(r[name]['measured_seconds'] for r in records),
                   'total_seconds': sum(r[name]['measured_seconds'] for r in records)}
            for name in ['legacy', 'contract']}
    return {'case_templates': by_template, 'categories': categories, 'costs': cost,
            'all_cases': len(records), 'families': len(plan['families']),
            'interpretation': 'Designed related synthetic cases. Counts measure conformance to partial mechanical obligations, not unbiased prevalence, semantic correctness, repair rate or independent software tasks. Known false reassurance and unsupported cases remain visible.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, default=ROOT / 'configs/evidence_contract_conformance_v1.json')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError('Preserve earlier conformance attempts')
    plan = json.loads(args.plan.read_text())
    legacy = module(ROOT / 'architecture/witness_ledger_v4.py', 'conformance_legacy')
    contract = module(ROOT / 'architecture/witness_contract_v1.py', 'conformance_contract')
    records = []
    with tempfile.TemporaryDirectory(prefix='bear_conformance_') as temporary:
        top = Path(temporary)
        for family in plan['families']:
            for template in plan['cases_per_family']:
                specification = fixture(family, template)
                case = top / family / template
                root = case / 'repo'
                initialise(root, specification['starting_source'])
                witness = case / 'check.py'
                witness.write_text(specification['witness'])
                current_source = root / 'src/demo/api.py'
                results = {}
                for name, method in [('legacy', legacy.evaluate), ('contract', contract.evaluate)]:
                    current_source.write_text(specification['current_source'])
                    before = time.monotonic()
                    result = method(root, case / name, witness)
                    result['measured_seconds'] = time.monotonic() - before
                    results[name] = result
                base, extra = results['legacy'], results['contract']
                category = ('supported_positive' if template in plan['positive_templates']
                            else 'mechanical_negative' if template in plan['mechanical_negative_templates']
                            else 'explicit_limit')
                decisions = {'current_exit_zero': (base.get('current') or {}).get('status') == 'passed',
                    'source_call_and_exit_zero': (base.get('current') or {}).get('status') == 'passed'
                        and bool((base.get('current') or {}).get('source_function_site_count')),
                    'legacy_v4_sensitive_transition': base['status'] == 'sensitive_transition',
                    'assertion_contract_v1': extra['mechanical_certificate']}
                records.append({'family': family, 'template': template, 'category': category,
                                'specification': specification, 'decisions': decisions, **results})
            print(json.dumps({'family_complete': family, 'records': len(records)}), flush=True)
    if len(records) != plan['total_cases']:
        raise ValueError('Incomplete registered matrix')
    sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    implementation_names = ['scripts/run_evidence_conformance.py', 'architecture/assertion_contract.py',
                             'architecture/witness_contract_v1.py', 'architecture/witness_ledger_v4.py']
    result = {'created_utc': datetime.now(timezone.utc).isoformat(),
              'plan_sha256': sha(args.plan), 'plan': plan, 'python': sys.version,
              'source_sha256': {name: sha(ROOT / name) for name in implementation_names},
              'model_calls': 0, 'summary': summarize(records, plan), 'records': records}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result['summary'], indent=2))


if __name__ == '__main__':
    main()
