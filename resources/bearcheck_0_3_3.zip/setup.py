"""Compatibility entry point for existing offline setuptools installations."""
from setuptools import setup

setup()
