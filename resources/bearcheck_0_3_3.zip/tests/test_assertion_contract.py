"""Exercise false reassurance and a conservative abstention boundary."""
import importlib.util
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('assertion_contract_subject', ROOT / 'architecture/witness_contract_v1.py')
subject = importlib.util.module_from_spec(spec)
spec.loader.exec_module(subject)


class AssertionContractTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory(prefix='bear_contract_test_')
        self.addCleanup(tmp.cleanup)
        self.top = Path(tmp.name)
        self.repo = self.top / 'repo'
        (self.repo / 'src/demo').mkdir(parents=True)
        (self.repo / 'src/demo/__init__.py').write_text('from .api import value\n')
        self.source = self.repo / 'src/demo/api.py'
        self.source.write_text('def value():\n    raise ValueError("starting defect")\n')
        subprocess.run(['git', 'init', '-q', str(self.repo)], check=True)
        subprocess.run(['git', '-C', str(self.repo), 'add', '.'], check=True)
        subprocess.run(['git', '-C', str(self.repo), '-c', 'user.name=Fixture',
                        '-c', 'user.email=fixture@localhost', 'commit', '-qm', 'baseline'], check=True)
        self.source.write_text('def value():\n    return 2\n')

    def run_check(self, code):
        witness = self.top / 'check.py'
        witness.write_text('from demo import value\n' + code)
        return subject.evaluate(self.repo, self.top / 'state', witness)

    def test_actual_return_assertion_keeps_fail_to_pass(self):
        record = self.run_check('assert value() == 2\n')
        self.assertTrue(record['mechanical_certificate'])
        self.assertEqual(record['current']['executed_assertion_lines'], [2])

    def test_unused_call_and_unrelated_assertion_no_longer_certified(self):
        record = self.run_check('value()\nexpected = 2\nassert expected == 2\n')
        self.assertEqual(record['legacy_status'], 'sensitive_transition')
        self.assertFalse(record['mechanical_certificate'])

    def test_skipped_assertion_is_not_a_passing_obligation(self):
        record = self.run_check('value()\nif False:\n    assert value() == 2\n')
        self.assertEqual(record['legacy_status'], 'sensitive_transition')
        self.assertEqual(record['current']['executed_assertion_lines'], [])
        self.assertFalse(record['mechanical_certificate'])

    def test_same_line_api_call_does_not_ground_independent_assertion(self):
        record = self.run_check('value(); assert 1 == 1\n')
        self.assertEqual(record['legacy_status'], 'sensitive_transition')
        self.assertFalse(record['mechanical_certificate'])

    def test_alias_before_overwrite_preserves_original_link(self):
        record = self.run_check('original = value()\nalias = original\noriginal = 7\nassert alias == 2\n')
        self.assertTrue(record['mechanical_certificate'])

    def test_user_helpers_abstain_instead_of_claiming_general_slicing(self):
        record = self.run_check('def obtain():\n    return value()\nassert obtain() == 2\n')
        self.assertFalse(record['mechanical_certificate'])
        self.assertIn('FunctionDef', record['assertion_contract']['unsupported_shapes'])

    def test_semantic_cancellation_remains_an_explicit_limit(self):
        record = self.run_check('observed = value()\nassert observed - observed == 0\n')
        self.assertTrue(record['mechanical_certificate'])
        self.assertEqual(record['semantic_relevance'], 'unassessed')


if __name__ == '__main__':
    unittest.main()
